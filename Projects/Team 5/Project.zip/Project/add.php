<?php
include 'header.php';
?>
<div class="space">
<form method="POST" action="upload.php" enctype="multipart/form-data">
          Name <input type="text" name="Name" /><br>
          Description <input type="text" name="Description" /><br>
          Price <input type="text" name="Price" /><br>
          Category <input type="text" name="Category" /><br>
          Stock <input type="text" name="Stock" /><br>
          <button type="submit">Add</button>
        </form>
<?php
$res.="<br><a href=\"admin.php\" target=\"_blank\"> <input type=\"button\" value=\"Return\"> </a>";


if (isset($_POST['Name']))
{
  $new = "INSERT INTO product (name,descr,category,stock,img,price) VALUES ('".$_POST['Name']."','".$_POST['Description']."','".$_POST['Category']."','".$_POST['Stock']."','mx','".$_POST['Price']."')";
  $bdd->query($new);
  $res.= "<p style=\"color:green;\">Product added!<p>";
}

echo $res."</div>";
