<?php
include 'header.php';
?>
<div class="space">
<h1>You are connected.</h1>
  <h2>
<?php
if(!empty($_SESSION['mail'])){
echo "Mail : " . $_SESSION['mail'];
}
?>
</h2>
<br><br><a href="invoices.php" target="_blank"> <input type="button" value="Show invoices"> </a>
</div>
<?php
