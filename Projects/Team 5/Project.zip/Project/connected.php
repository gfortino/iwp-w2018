<?php
include 'header.php';
?>
<div class="space">
  <!-- Page displayed when you are a consumer -->
<h1>You are connected.</h1>
  <h2>
<?php
if(!empty($_SESSION['mail'])){
echo "Mail : " . $_SESSION['mail'];
}
?>
</h2>
<!-- Button to show the invoices -->
<br><br><a href="invoices.php" target="_blank"> <input type="button" value="Show invoices"> </a>
</div>
<?php
