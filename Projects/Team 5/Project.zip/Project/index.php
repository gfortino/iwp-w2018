<?php
include 'header.php';
?>
<div class="space">
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Product</th>
            <th scope="col">Name</th>
            <th scope="col">Description</th>
            <th scope="col">Price</th>
            <th scope="col">Stock</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
<?php
$ctg = $bdd->query('SELECT DISTINCT(category) FROM product');
$form = "<FORM method=\"POST\">
          <SELECT name=\"btn\" onchange=\"this.form.submit()\">
            <OPTION disabled selected value>Select Category</OPTION>
            <OPTION value=\"All\">All</OPTION>";
while ($data = $ctg->fetch()){
    $form .= "<OPTION  value=\"".$data['category']."\">".$data['category']."</option>";
}
$form .= "</SELECT></form>";
echo $form;
if (isset($_POST['btn'])){
  if($_POST['btn'] == 'All'){
    $sql = "SELECT * FROM product";
  }else{
    $sql = "SELECT * FROM product WHERE category = '" . $_POST['btn'] . "'";
  }
}else{
    $sql = "SELECT * FROM product";
}
$response = $bdd->query($sql);
while ($data = $response->fetch())
{
    $row = "<tr><td><img height=\"30%\" width=\"40%\" src=\"IMG/";
    $row .= $data['img'] . ".jpg\"></td><td>" . $data['name'] . "</td><td style=\"width:30%; text-align: justify;\">" . $data['descr'] . "</td><td>" . $data['price'] . " \$CAN</td><td>" . $data['stock'] . "</td>";
if(!empty($_SESSION['mail'])){
    $row .= "<td><form method=\"POST\"><button type='submit' name = 'add' value = '".$data['name']."'>Add</button></form></td><tr>";
}
    echo $row;
}
if (isset($_POST['add']))
{
  $sql1 = "SELECT idUser FROM user WHERE mail='".$_SESSION['mail']."'";
  $sc1 = $bdd->query($sql1);
  $id = $sc1->fetch();
  $test = "SELECT product, idUser FROM shoppCart WHERE idUser = ".$id['idUser']." AND finish = 0";

  $test2= $bdd->query($test);
  $alreadyIn = 0;
  while($prod = $test2->fetch()){
    if($prod['product'] == $_POST['add']){
      $alreadyIn = 1;
    }
  }
if($alreadyIn == 1){
    $nbItem = "UPDATE shoppCart
               SET nbItem = nbItem+1
               WHERE product= '".$_POST['add']."'
               AND finish=0";
    $bdd->query($nbItem);
  }else{
    $insert = "INSERT INTO shoppCart(product,idUser,nbItem,finish) VALUES ('".$_POST['add']."', ".$id['idUser'].",'1','0')";
    $bdd->query($insert);
  }
    $stock = "UPDATE product
              SET stock=stock-1
              WHERE name = '".$_POST['add']."' ";
    $bdd->query($stock);
    echo "<meta http-equiv=\"refresh\" content=\"1;url=index.php\"/>";

}
?>
</tbody>
</table>
</div>
</body>
