-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  lun. 16 avr. 2018 à 04:17
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projectBDD`
--

-- --------------------------------------------------------

--
-- Structure de la table `product`
--

CREATE TABLE `product` (
  `name` varchar(50) NOT NULL,
  `stock` int(11) NOT NULL,
  `img` varchar(20) NOT NULL,
  `price` float NOT NULL,
  `descr` text NOT NULL,
  `category` varchar(20) NOT NULL,
  `idProduct` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `product`
--

INSERT INTO `product` (`name`, `stock`, `img`, `price`, `descr`, `category`, `idProduct`) VALUES
('Apple 15\" MacBook Pro Retina Touch Bar', 90, 'ambp', 1049.99, 'MacBook Pro elevates the notebook to a whole new level of performance and portability. Wherever your ideas take you, you’ll get there faster than ever with cutting-edge graphics, high-performance processors, whip-smart storage, and more. With seventh-generation Intel Core processors, MacBook Pro delivers amazing performance so you can move fast — even when powering through pro-level processing jobs like rendering 3D models and encoding video. At the same time, it can conserve energy when taking on lighter tasks, like browsing the web and checking email. ', 'Computers', 1),
('Apple iPhone X 5.8\", 64 GB - Silver', 70, 'ix', 1671.79, '5.8 inch Super Retina screen with all-screen OLED Multi-Touch display\r\n12MP wide-angle and telephoto cameras with Dual optical image stabilization\r\nWireless Qi charging\r\nSplash, water, and dust resistant\r\nSapphire crystal lens cover\r\n', 'Cell Phones', 2),
('ASUS ROG Zephyrus GX501VI-XS74 15.6\"', 98, 'arz', 3390.96, 'Ultra-thin and ultra-light with a thickness of only 0.7\" (with the lid closed) and weighing only 4.9 lbs\r\nNext-generation performance with GeForce GTX 1070 8GB with Max-Q design and Intel Core i7-7700HQ 2.8 GHz Processor (Turbo up to 3.8GHz). Windows 10 Pro. 120Hz Panel\r\nQuiet and cool featuring ROG Active Aerodynamic System which improves airflow by 40% and reduces temperatures by 20% compared to conventional cooling. *Actual cooling performance varies due to system and environmental conditions ', 'Computers', 3),
('Beats by Dr. Dre Studio 3 Wireless', 97, 'b3w', 399.95, 'Features the iconic Beats sound with Dual-Mode Adaptive Noise Canceling, plus the added benefit of wireless listening.\r\nPair and Play with your Bluetooth device with 30ft range.\r\n12-hour rechargeable battery with Fuel Gauge. Soft over ear cushions for extended comfort and added noise isolation\r\nSoft ear cups have an ergonomic bellow that creates a flexible custom fit, so you can keep your music all to yourself. ', 'Headphones', 4),
('Samsung Galaxy S8 64GB', 98, 'sgS8', 799.95, 'Infinity Display: a bezel-less, full-frontal, edge-to-edge screen. Default resolution is Full HD+ and can be changed to Quad HD+ (WQHD+) in Settings\r\nCamera resolution - Front: 8 MP AF, Rear: 12 MP OIS AF\r\nMemory: Internal Memory 64 GB, RAM 4GB\r\nInternational model phone, will work with Most\r\nGSM SIM cards in U.S. and world Including AT&T, T-Mobile, MetroPCS,Etc. Does not have US warranty. Will NOT work with CDMA Carriers such as Verizon, Sprint, etc.\r\n', 'Cell Phones', 7),
('Sennheiser HD 4.50 BTNC WIRELESS', 99, 'shd', 229.95, 'Bluetooth 4.0 and aptX technologies to deliver exceptional wireless sound quality..Connectivity Technology: Wireless\r\nNoiseGard active noise cancellation to reduce ambient noise levels improving the listening experience.\r\nIntuitive ear-cup mounted controls for changing tracks and for making calls via the integrated microphone.\r\nUp to 19 hour battery life with Bluetooth and NoiseGard activated and is supplied with connecting cable for battery-free listening\r\n2 year warranty when purchased from an authorized Sennheiser dealer ', 'Headphones', 8);

-- --------------------------------------------------------

--
-- Structure de la table `shoppCart`
--

CREATE TABLE `shoppCart` (
  `product` varchar(50) NOT NULL,
  `idUser` int(11) NOT NULL,
  `nbItem` int(11) NOT NULL,
  `idSc` int(11) NOT NULL,
  `finish` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `User`
--

CREATE TABLE `User` (
  `idUser` int(1) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `User`
--

INSERT INTO `User` (`idUser`, `mail`, `password`) VALUES
(1, 'admin@admin.fr', '1234');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`idProduct`);

--
-- Index pour la table `shoppCart`
--
ALTER TABLE `shoppCart`
  ADD PRIMARY KEY (`idSc`),
  ADD KEY `product` (`product`);

--
-- Index pour la table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`idUser`),
  ADD UNIQUE KEY `mail` (`mail`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `product`
--
ALTER TABLE `product`
  MODIFY `idProduct` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT pour la table `shoppCart`
--
ALTER TABLE `shoppCart`
  MODIFY `idSc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `User`
--
ALTER TABLE `User`
  MODIFY `idUser` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
