<?php
include 'header.php';


echo "<div class = \"space\"><h1>Successful payment <span class=\"glyphicon glyphicon-ok\"></span></h1>";

echo "<br><a href=\"index.php\" target=\"_blank\"> <input type=\"button\" value=\"Return\"> </a></div>";
