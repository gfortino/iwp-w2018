<?php
include 'header.php';
?>
<div class="space">
  <!-- Admin panel, with all features -->
  <h1>Admin panel</h1>
    <br><a href="add.php" target="_blank"> <input type="button" value="Add product"> </a>
    <br><a href="delete.php" target="_blank"> <input type="button" value="Manage"> </a>
    <br><a href="orders.php" target="_blank"> <input type="button" value="Pending orders"> </a>
</div>
