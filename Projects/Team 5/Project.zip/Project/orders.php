<?php
include 'header.php';
?>

<?php
$sql = "SELECT product,nbItem,price, finish,idProduct FROM shoppCart s, product p WHERE finish!=0 AND name = product";
$ctg = $bdd->query($sql);

?>
<div class="space">
<table class="table">
<tr>
    <th scope="col">Product</th>
    <th scope="col">Quantity</th>
    <th scope="col">Shipment</th>
    <th scope="col">Action</th>
</tr>

<?php
while($data =$ctg->fetch()){
  $res .= "<tr><td>".$data['product']."</td><td>".$data['nbItem']."</td>";
  if($data['finish']==2){
$res.="<td><span class=\"glyphicon glyphicon-ok\"></span> Shipped !</td>
      <td>
      <form method=\"POST\"><button name=\"cancel\"value=\"".$data['idProduct']."\"type=\"submit\"><span class=\"glyphicon glyphicon-remove\"></button></span></td>
                  <td>
      </form>
      </tr>";
}else if($data['finish']==1){
    $res.="<td><span class=\"glyphicon glyphicon-time\"></span> Waiting shipment</td>
    <td>
    <form method=\"POST\"><button name=\"ship\"value=\"".$data['idProduct']."\"type=\"submit\"><span class=\"glyphicon glyphicon-ok\"></button></span></td>
                <td>
    </form>
    </tr>";

  }
}

$res.="</table>";


$res.="<br><br><a href=\"connected.php\" target=\"_blank\"> <input type=\"button\" value=\"Return\"> </a></div>";
echo $res;

if (isset($_POST['ship']))
{

  $sql = "UPDATE shoppCart, product
          SET finish=2
          WHERE idProduct='".$_POST['ship']."'AND name=product";
  $bdd->query($sql);
  echo "<meta http-equiv=\"refresh\" content=\"1;url=orders.php\"/>";

}else if (isset($_POST['cancel'])){

  $sql = "UPDATE shoppCart,product
          SET finish=1
          WHERE idProduct='".$_POST['cancel']."' AND name=product";
  $bdd->query($sql);
  echo "<meta http-equiv=\"refresh\" content=\"1;url=orders.php\"/>";

}
?>
