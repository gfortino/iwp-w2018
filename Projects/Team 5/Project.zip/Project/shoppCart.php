<?php
include 'header.php';
if (empty($_SESSION['mail'])) {
// If you are not log in, you are redirect to the log in/ sign in page
  echo "<div class=\"space\"><h2>Redirecting</h2></div><meta http-equiv=\"refresh\" content=\"1;url=account.php\"/>";
}else{
  // If you are log in, you can make a shopping cart
$sql = "SELECT product, price, nbItem, "."s.idUser"." FROM shoppCart s, product p, user u WHERE "."s.product"."= p.name AND "."u.mail"." = '".$_SESSION['mail']."' AND "."u.idUser"."="."s.idUser"." AND finish=0";
$sc = $bdd->query($sql);
$res = "<div class=\"space\"><table class=\"table\"><thead class=\"thead-dark\"><tbody>
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
        </tr>
        </thead>";
$price = 0;
// Retrieve all product (with price, quantity) that you added in your shopping cart
while ($data = $sc->fetch()){
  $res .= "<tr><td>".$data['product']."</td><td>".$data['price']." \$CAN</td><td>".$data['nbItem']."</td></tr>";
  $price += $data['price']*$data['nbItem'];
}
$res .= "</tbody></table>";
$res .="<b>Total: " . $price . " \$CAN<br>";
$res .=  "<img src=\"IMG/payment.jpg\"  height=\"75\" width=\"290\">";
$res .= "<br><form method=\"POST\">
    <input name=\"pay\" type=\"submit\" value=\"Payment\"/></form> </div> ";
    echo $res;
    // If button payment are pressed, your will be redirect to the payment page
    // An update is made in the DDB 
    if (isset($_POST['pay']))
    {
      $sql1 = "SELECT idUser FROM user WHERE mail='".$_SESSION['mail']."'";
      $sc1 = $bdd->query($sql1);
      $id = $sc1->fetch();
      $sql = "UPDATE shoppCart SET finish = 1 WHERE idUser=".$id['idUser']."";
      $sc = $bdd->query($sql);
      echo "<meta http-equiv=\"refresh\" content=\"1;url=payment.php\"/>";
    }
}
