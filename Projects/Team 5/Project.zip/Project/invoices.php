<?php
include 'header.php';
?>

<?php
if(!empty($_SESSION['mail'])){
  // Only products which are paid are displayed
$total = 0;
$sql1 = "SELECT idUser FROM user WHERE mail='".$_SESSION['mail']."'";
$sc1 = $bdd->query($sql1);
$id = $sc1->fetch();
$sql = "SELECT product,nbItem,price, finish FROM shoppCart s, product p WHERE finish!=0 AND "."s.idUser"."=".$id['idUser']." AND name = product";
$ctg = $bdd->query($sql);

?>
<div class="space">
<table class="table">
<tr>
    <th scope="col">Product</th>
    <th scope="col">Quantity</th>
    <th scope="col">Shipment</th>
</tr>

<?php
// The list is displayed
// You can see if the product is shipped or not
while($data =$ctg->fetch()){
  $res .= "<tr><td>".$data['product']."</td><td>".$data['nbItem']."</td>";
  if($data['finish']==2){
$res.="<td><span class=\"glyphicon glyphicon-ok\"></span> Shipped !</tr>";
}else if($data['finish']==1){
    $res.="<td><span class=\"glyphicon glyphicon-time\"></span> Waiting shipment<td></tr>";

  }
  // Total in $CAN is displayed
  $total += $data['price']*$data['nbItem'];
}

$res.="</table>";
$res.="<b>Total orders: " .$total." \$CAN</b>";

}
$res.="<br><br><a href=\"connected.php\" target=\"_blank\"> <input type=\"button\" value=\"Return\"> </a></div>";
echo $res;
?>
