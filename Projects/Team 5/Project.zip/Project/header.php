<?php
// This header is included in all the pages
// Start session
session_start();
// Initialize content
$res = "";
// Connection BDD
$bdd = new PDO('mysql:host=localhost;dbname=projectBDD;charset=utf8', 'root', '');
?>

<html>
<head>
  <!-- Bootstrap -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link href="CSS/style.css" rel="stylesheet">
    <link rel="icon" href="IMG/favicon.ico" type="image/gif" sizes="16x16">
    <title>Online Store</title>
</head>
<!-- Naviagation bar -->
<body>
    <nav class="navbar navbar-dark bg-dark">
        <ul class="nav navbar-nav">
            <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
            <li><a href="shoppCart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Shopping Cart</a></li>
            <li><a href="account.php"><span class="glyphicon glyphicon-user"></span> Account</a></li>
<?php
// Deconnection button if connected
if(! empty($_SESSION['mail'])){
?>
            <li><a href="account.php"><span class="glyphicon glyphicon-ok"></span> <?php echo $_SESSION['mail'] ?></a></li>
            <li><form method="POST">
              <button style="margin-top:10%" type="submit" name="deco">
                Deconnection
              </button>
              <form></li>
<?php
}
// If deco button is pressed
if (isset($_POST['deco'])){
  // Deconnection
  session_unset();
  session_destroy();
  // Refresh
  echo "<meta http-equiv=\"refresh\" content=\"1;url=index.php\"/>";
}
?>
</ul>
</nav>
