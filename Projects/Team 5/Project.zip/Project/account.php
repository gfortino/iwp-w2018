<?php
include 'header.php';
// Is you are not log in, sign in/log in form are shown
if(empty($_SESSION['mail'])){
?>
<html>
<div class="space">

<!-- Log in form -->
<h2>Log in</h2><br>
<form method=POST>
   <label>Email:</label>
     <input type="email" name="mail" placeholder="Enter email" autocomplete="off"><br>
   <label>Password:</label>
     <input type="password" name="password" placeholder="Enter password" autocomplete="off"><br><br>
     <button type="submit" class="btn btn-default">Submit</button>
</form><br>

<!-- Sign in form -->
<h2>Sign in</h2><br>
<form method=POST>
   <label>Email:</label>
     <input type="email" name="newmail" placeholder="Enter email" autocomplete="off"><br>
   <label>Password:</label>
     <input type="password" name="newpassword" placeholder="Enter password" autocomplete="off"><br><br>
     <button type="submit" class="btn btn-default">Submit</button>
</form>


<?php
// If log in form is submitted
if (isset($_POST['mail'])){
  // Search in DDB if user existes
  $con = "SELECT mail, password FROM user WHERE mail='".$_POST['mail']."' AND password='".$_POST['password']."'";
  $info = $bdd->query($con);
  $infos = $info->fetchAll();
  // If yes, informations are put into the variables of the session
if(count($infos)!=0){
  $_SESSION['mail'] = $_POST['mail'];
  $_SESSION['password'] = $_POST['password'];
  $res .= "<meta http-equiv=\"refresh\" content=\"1;url=account.php\"/>";
  }else{
    // If not, error message displayed
    echo "<h3>Invalid identifiers</h3>";
  }

}
// If sign in form is submitted
if (isset($_POST['newmail'])){
  // Informations are put into the variables of the session
  $_SESSION['mail'] = $_POST['newmail'];
  $_SESSION['password'] = $_POST['newpassword'];
  // and inserted in the DDB
  $new = "INSERT INTO user (mail,password) VALUES ('".$_POST['newmail']."','".$_POST['newpassword']."')";
  $bdd->query($new);
  $res .=  "<meta http-equiv=\"refresh\" content=\"1;url=account.php\"/>";
}
}else{
  // If you are log in as a consumer
  if($_SESSION['mail']!='admin@admin.fr'){
  $res .= "<meta http-equiv=\"refresh\" content=\"1;url=connected.php\"/>";
}
// If you are log in as a the administrator, you will be redirected on the admin panel
    else{
      $res .= "<meta http-equiv=\"refresh\" content=\"1;url=admin.php\"/>";
    }
}
echo $res."</div>
</html>";
?>
