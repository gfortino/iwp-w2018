<?php
include 'header.php';
// Admin feature : manage
// Table of products
$res = "<div class=\"space\"><table class=\"table\"><thead class=\"thead-dark\"><tbody>
        <tr>
            <th>Product</th>
            <th>Stock</th>
            <th>Delete</th>
        </tr>
        </thead>";
$all = "SELECT stock, name, idProduct FROM product";
$allProd = $bdd->query($all);
while($data = $allProd->fetch()){
  // Row with the product informations, option to modify the stock and button to delete the product from the DDB
$res.= "<tr><td>".$data['name']."</td>
<td><form method=\"POST\"> ".$data['stock']." <input style=\"width:10%\" type=\"text\" name=\"stock\" autocomplete=\"off\"> <button name=\"ok\"value=\"".$data['idProduct']."\"type=\"submit\"> Update </button></td>
            <td>
              <button type=\"submit\" name=\"delete\" value=\"".$data['idProduct']."\">Delete</button>
            </td></form></tr>";
}
$res .= "</tbody></table>";
$res.= "<br><form action=\"admin.php\">
    <input type=\"submit\" value=\"Return\"/></form> ";
    // If delete button is pressed
    if (isset($_POST['delete']))
    {
      // The product are deleted
      $del = "DELETE FROM PRODUCT WHERE idProduct = '".$_POST['delete']."'";
      $bdd->query($del);
      $res.= "<p style=\"color:red;\">Product deleted!<p>";
      echo "<meta http-equiv=\"refresh\" content=\"1;url=delete.php\"/>";

    }
    // If the quantity is modified
   if (isset($_POST['ok'])){
    if (isset($_POST['stock']))
    {
      // The informations are updated in the DDB
      $stock = "UPDATE product
                 SET stock = '".$_POST['stock']."'
                 WHERE idProduct= '".$_POST['ok']."' ";

      $bdd->query($stock);
      $res.= "<p style=\"color:green;\">Stock modified!<p>";
            echo "<meta http-equiv=\"refresh\" content=\"1;url=delete.php\"/>";
    }}
echo $res."</div>";
