<?php require_once dirname(__FILE__) . '/../../models/functions.php';?>
<?php $attributes = array('class' => "form-inline", "method"=>"GET");?>
<div class="col-md-10 col-md-offset-1">
    <h4 align="center">Kart</h4>
    <div class="well well-sm" style="background-color:#FFFFFF; /*height:260px;*/ border:1px  ; overflow-x:hidden; overflow-y:scroll;">
        <div class="row">
            <?php $total=0;$tva=0;?>
            <?php foreach ($kart_elements as $un_product): ?>
                <div class="col-sm-4 col-md-3">
                    <div class="thumbnail">
                        <?php show_product_photos($un_product['rowid'])?>
                        <div class="caption">
                            <h3><?php echo $un_product['label']?></h3>
                            <p><?php echo $un_product['description']?></p>
                            <!--<p><a href="<?php echo base_url()."index.php/products/add_to_kart/".$un_product['rowid']?>" class="btn btn-primary" role="button">ADD</a> <a href="#" class="btn btn-default" role="button">More info</a></p>-->
                            <p>Quantity:<?php echo $un_product['qty']?>
                                <a href="<?php echo base_url()."index.php/products/info_product/".$un_product['rowid']?>" class="btn btn-default" role="button">More info</a></p>
                        </div>
                    </div>
                </div>
                <?php $total+=$un_product['price']*$un_product['qty']?>
                <?php $tva+=$un_product['tva_tx']/100*$un_product['price']*$un_product['qty']?>
            <?php endforeach; ?>
        </div>
        <h4>Tva: <?php echo $tva?></h4>
        <h4>Total: <?php echo $total?></h4>
        <h4>Total_ttc: <?php echo $total+$tva?></h4>
    </div>
</div>