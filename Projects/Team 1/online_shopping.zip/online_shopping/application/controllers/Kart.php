<?php
require_once dirname(__FILE__) . '/../models/functions.php';
require_once dirname(__FILE__) . '/../Classes/PHPExcel.php';


class Kart extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Kart_model');
        $this->load->helper('url_helper');
        //$this->config->set_item('language', 'chinese');
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
        $this->config->set_item('language', $_SESSION['language']);
        $this->lang->load('menu');
        $this->load->helper('language');
    }
    public function show_kart_elements(){
        $data['kart_elements']=$this->Kart_model->fetch_kart();
        $this->load->view('templates/header', $data);
        $this->load->view('kart/show_kart_elements' , $data);
        $this->load->view('templates/footer', $data);
    }


}