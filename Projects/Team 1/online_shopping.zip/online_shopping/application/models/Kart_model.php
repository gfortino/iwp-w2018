<?php
class Kart_model extends CI_Model{
    //用来处理创建产品时的厂家价格类

    public function __construct()
    {
        $this->load->database();
        $this->load->library('session');
        $this->load->helper('url');
    }
    /************************************/
    public function fetch_kart(){
        //$query = $this->db->get_where('llx_product', array('ref' => $ref));
        $this->db->select("p.rowid, p.ref, p.label, p.description, p.price, p.tva_tx, p.note, kc.qty");
        $this->db->from("llx_product p,llx_kart_client kc");
        $this->db->where("p.rowid=kc.fk_product");
        $this->db->where('kc.fk_user',$_SESSION['rowid']);
        $query=$this->db->get();

        return $query->result_array();
    }

}