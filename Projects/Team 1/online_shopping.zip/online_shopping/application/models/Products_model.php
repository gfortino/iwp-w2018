<?php
    class Products_model extends CI_Model{
        //用来处理创建产品时的厂家价格类

        public function __construct()
        {
            $this->load->database();
            $this->load->library('session');
            $this->load->helper('url');
        }
        /************************************/
        public function get_products_by_rowid($rowid=false){
            //$query = $this->db->get_where('llx_product', array('ref' => $ref));
            $this->db->select("p.rowid, p.ref, p.label, p.description, p.price, p.tva_tx,
                               p.datec, p.tms,
                               p.stock, p.note");
            $this->db->from("llx_product p");
            $this->db->where('p.rowid',$rowid);
            $query=$this->db->get();

            return $query->result_array();
        }

        //用于ajax检查ref是否重复
        public function get_products_by_ref($ref=false){

            //$query = $this->db->get_where('llx_product', array('ref' => $ref));
            $this->db->select("llx_product.rowid");
            $this->db->from("llx_product");
            //$this->db->join('llx_product_extrafields','llx_product_extrafields.fk_object=llx_product.rowid','left'); //extrafields
            $this->db->where('llx_product.ref',$ref);
            $query=$this->db->get();

            return $query->result_array();
        }
        //获得产品总数：用于分页
        public function count_products(){
            $query = $this->db->query('SELECT rowid FROM llx_product');
            return $query->num_rows();
        }
        //获得分页的产品
        public function fetch_product($limit,$offset,$categ_id=null){
            $ref=$this->input->get('ref');
            $this->db->limit($limit,$offset);
            $this->db->select("p.rowid, p.ref, p.label, p.description, p.price");
            $this->db->from("llx_product p");
            $this->db->like("p.ref",$ref);
            $this->db->order_by("p.rowid", "desc");
            //$this->db->join('llx_categorie_product cp','cp.fk_product=p.rowid','left'); //标签-产品关系
            //$this->db->join('llx_categorie c','c.rowid=cp.fk_categorie and c.fk_parent=0','left'); //标签
            //$this->db->join('llx_categorie_lang cl','cl.fk_category=c.rowid and cl.lang="zh_CN"','left'); //标签翻译
            $query=$this->db->get();
            $result=$query->result_array();

            return $result;
        }

        public function get_products_by_ref_like(){
            $ref=$this->input->post('ref');
            //$query = $this->db->get_where('llx_product', array('ref' => $ref));
            $this->db->select("*");
            $this->db->from("llx_product");
            $this->db->where("tosell=1");//是可销售和可采购的产品
            $this->db->where("tobuy=1");
            $this->db->like("ref",$ref);
            $this->db->order_by("llx_product.rowid", "desc");
            $query=$this->db->get();

            return $query->result_array();
        }
        /*添加或者更新产品*/
        //rowid==null时则添加产品，不为null时则更新该rowid产品 !!
        public function replace_product($rowid=null){
            $price=$this->input->post('price');//因为价格基准是含增值税，所以这里输入的价格是税后价格
            $tva_tx=$this->input->post('tva_tx');

            //获取当前时间，插入数据库时需要
            $tms=date("Y-m-d h:i::sa");
            $surface=$this->input->post('long')*$this->input->post('wide');
            $volume=$this->input->post('hight')*$surface;
            $data = array(
                'ref' => $this->input->post('ref'),
                'label' => $this->input->post('label'),
                'description'=>$this->input->post('description'),
                'price'=>$price,
                'tva_tx'=>$tva_tx,
                'stock'=>$this->input->post('stock'),
                'note'=>$this->input->post('note'),
            );
            if($rowid==null) {
                $data['datec']=$tms;//创建时间只有在创建产品的时候才会记录
                //$data['fk_user_author']=$_SESSION['rowid'];//是哪个用户创建的
                //$data['fk_user_modif']=$_SESSION['rowid'];//是哪个用户改变的
                $this->db->insert('llx_product', $data);
                $id=$this->db->insert_id();//获得刚刚添加的产品的id
            }
            else{
                $this->db->where('rowid', $rowid);
                //$data['fk_user_modif']=$_SESSION['rowid'];//是哪个用户改变的
                $this->db->update('llx_product', $data);
                $id=$rowid;//这里用id就是rowid，加id来区分目的是区分rowid之前是不是null
            }

            return $id;

        }

        //用rowid号删除整个产品
        public function delete_by_rowid($rowid){
            //获得该产品的ref
            $ref=$this->get_ref_by_rowid($rowid);//要先获得ref，不然删了就不能获得了
            //删掉供应商的价格
            $this->Fournisseur_product_model->delete_product_fournisseur_price($rowid);

            //删掉产品的categorie关系
            $this->db->delete('llx_categorie_product',array('fk_product'=>$rowid));
            $this->db->delete('llx_product_price', array('fk_product' => $rowid));//需要先删掉价格
            $this->db->delete('llx_product_lang',array('fk_product'=>$rowid));//删掉多语言
            $this->db->delete('llx_product', array('rowid' => $rowid));  // Produces: // DELETE FROM llx_product  // WHERE rowid = $rowid
            //删掉图片
            $dir='../'.$_SESSION["folder"].'/documents/produit/'.$ref;
            $photos=get_photo_list($dir);
            if($photos!=NULL) {
                foreach ($photos as $name){
                    unlink($dir.'/'.$name);
                }
            }
            //删掉产品的extrafield
            $this->db->delete('llx_product_extrafields',array('fk_object'=>$rowid));
        }
        //删除多个产品
        public function delete_proudcts(){
            $products=$this->input->post('product_check_box');
            if($products!=null) {
                foreach ($products as $value) {
                    echo " ".$value." ";
                    $this->delete_by_rowid($value);
                }
            }
        }

        //添加到购物车
        public function add_to_kart($fk_product){
            //检查这个记录是否存在
            $this->db->select('rowid');
            $this->db->from("llx_kart_client kc");
            $this->db->where("kc.fk_product",$fk_product);
            $this->db->where("kc.fk_user",$_SESSION['rowid']);
            $query=$this->db->get();
            //如果已经添加了这个产品，则添加数量
            if($query->result_array()==NULL){
                $data = array(
                    'fk_product' => $fk_product,
                    'fk_user' => $_SESSION['rowid'],
                    'qty' => 1
                );
                $this->db->insert('llx_kart_client', $data);
            }
            //update
            else{
                $this->db->where('fk_product',$fk_product);
                $this->db->where('fk_user',$_SESSION['rowid']);
                $this->db->set('qty', 'ifnull(qty,0)+1', FALSE);
                $this->db->update('llx_kart_client');
            }

            //减少库存数量
            $this->db->where("rowid",$fk_product);
            $this->db->set("stock",'ifnull(stock,0)-1', FALSE);
            $this->db->update('llx_product');
        }


    }